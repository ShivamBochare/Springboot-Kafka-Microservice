# Springboot-Kafka-Microservice
Spring boot kafka producer consumer project
