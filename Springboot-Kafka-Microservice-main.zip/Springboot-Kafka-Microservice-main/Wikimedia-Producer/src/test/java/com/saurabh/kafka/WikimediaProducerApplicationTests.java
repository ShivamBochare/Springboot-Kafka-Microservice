package com.saurabh.kafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WikimediaProducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
